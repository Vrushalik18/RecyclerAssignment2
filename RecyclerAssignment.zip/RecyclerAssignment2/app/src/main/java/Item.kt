data class Item(
    val name: String,
    var isSelected: Boolean = false)